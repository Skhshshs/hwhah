package dev.lagswitch;

import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.Packet;

import java.util.ArrayList;
import java.util.List;

public class LagSwitch extends Module {
    private final List<Packet<?>> packetQueue = new ArrayList<>();

    public LagSwitch() {
        super(Category.Misc, "lag-switch", "Giữ lại packet để tạo ping cao, bấm 1 phím bật/tắt.");
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (isActive()) {
            event.cancel();
            packetQueue.add(event.packet);
        }
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!isActive() && !packetQueue.isEmpty()) {
            for (Packet<?> p : packetQueue) {
                mc.getNetworkHandler().sendPacket(p);
            }
            packetQueue.clear();
        }
    }
}