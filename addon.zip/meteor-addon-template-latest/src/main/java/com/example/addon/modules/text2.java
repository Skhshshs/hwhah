package dev.lagswitch;

import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.Packet;

import java.util.LinkedList;
import java.util.Queue;

public class SlowNet extends Module {
    private final Queue<Packet<?>> queue = new LinkedList<>();
    private long lastSendTime = 0;

    public SlowNet() {
        super(Category.Misc, "slow-net", "Giảm tốc độ gửi packet để tăng ping giả.");
    }

    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (isActive()) {
            event.cancel();
            queue.add(event.packet);
        }
    }

    @Override
    public void onTick() {
        if (!isActive()) {
            // Nếu tắt module, gửi hết
            while (!queue.isEmpty()) mc.getNetworkHandler().sendPacket(queue.poll());
            return;
        }

        // Mỗi 300ms mới gửi 1 packet
        if (!queue.isEmpty() && System.currentTimeMillis() - lastSendTime > 300) {
            mc.getNetworkHandler().sendPacket(queue.poll());
            lastSendTime = System.currentTimeMillis();
        }
    }
}